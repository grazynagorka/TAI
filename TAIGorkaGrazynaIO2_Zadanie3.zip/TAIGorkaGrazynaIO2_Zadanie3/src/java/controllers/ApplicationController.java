package controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ApplicationScoped;

/**
 *
 * @author Admin
 */
@ManagedBean
@ApplicationScoped
public class ApplicationController {
    
    String applicationVersion = "1.1.3";

    public ApplicationController() {
    }

    public String getApplicationVersion() {
        return applicationVersion;
    }

    public void setApplicationVersion(String applicationVersion) {
        this.applicationVersion = applicationVersion;
    }
    
}
