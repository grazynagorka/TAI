package controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

/**
 *
 * @author Admin
 */
@ManagedBean
@SessionScoped
public class SessionController {

    public SessionController() {
    }
    
    public String logout() {
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        externalContext.invalidateSession();
        
       return "/logoutWindow.xhtml?faces-redirect=true";
    }
    
}
