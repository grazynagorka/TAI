/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.application.controllers;

import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import pl.application.common.DataRow;
import pl.application.common.MenuItem;

/**
 *
 * @author Admin
 */
@ManagedBean
@SessionScoped
public class NewJSFManagedBeanSession {
ArrayList<MenuItem> menuItemList = new ArrayList();
    ArrayList<DataRow> dataRow = new ArrayList();
    

    public NewJSFManagedBeanSession() {
        menuItemList.add(new MenuItem("Karuzela","/views/carouselView"));
        menuItemList.add(new MenuItem("Tabela","/views/tableView"));
        menuItemList.add(new MenuItem("Wylogowanie","/logoutWindow"));
        
        dataRow.add(new DataRow("Adam","Nowak",25,"Warszawa","4545454545"));
        dataRow.add(new DataRow("Maciej","Kowalski",35,"Gdansk","425632"));
        dataRow.add(new DataRow("Kamil","Kaminski",37,"Gdynia","212121"));
        dataRow.add(new DataRow("Monika","Kownacka",22,"Sopot","546214363"));
        dataRow.add(new DataRow("Anna","Sklodowska",41,"Sopot","12121"));
        
    }

    public ArrayList<MenuItem> getMenuItemList() {
        return menuItemList;
    }

    public ArrayList<DataRow> getDataRow() {
        return dataRow;
    }
}
