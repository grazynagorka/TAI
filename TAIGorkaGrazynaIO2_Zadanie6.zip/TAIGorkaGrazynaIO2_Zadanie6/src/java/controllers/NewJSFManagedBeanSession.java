package controllers;

import dao.UzytkownikDao;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import to.UzytkownikTo;


@ManagedBean
@RequestScoped
public class NewJSFManagedBeanSession {
    java.util.List<UzytkownikTo> uzytkownikToList = new java.util.ArrayList();

    public NewJSFManagedBeanSession() {
        refreshData();
    }

    public List<UzytkownikTo> getUzytkownikToList() {
        return this.uzytkownikToList;
    }

    public final void refreshData() {
        UzytkownikDao daneDAO = new UzytkownikDao();
        java.util.List<UzytkownikTo> uzytkownikTOListLokal = daneDAO.findAll();
        if (uzytkownikTOListLokal != null) {
            uzytkownikToList.clear();
            uzytkownikToList = uzytkownikTOListLokal;
        }
    }

    public void setUzytkownikToList(List<UzytkownikTo> uzytkownikToList) {
        this.uzytkownikToList = uzytkownikToList;
    }

    public void visibleChange(UzytkownikTo uzytkownikTo) {
        int indexObject = uzytkownikToList.indexOf(uzytkownikTo);
        //uzytkownikTO.setStatus(UzytkownikTo.RowStatus.EDITED);
        UzytkownikDao daneDao = new UzytkownikDao();
        if (daneDao.update(uzytkownikTo) != -1) {
            uzytkownikToList.set(indexObject, uzytkownikTo);
        }

    }

    public void deleteRow(UzytkownikTo uzytkownikTo) {
        int indexObject = uzytkownikToList.indexOf(uzytkownikTo);
        UzytkownikDao daneDao = new UzytkownikDao();
        if (daneDao.delete(uzytkownikTo.getId()) != -1) {
            uzytkownikToList.remove(indexObject);
        }
    }

    public void addRow(UzytkownikTo uzytkownikTo) {
        int indexObject = uzytkownikToList.indexOf(uzytkownikTo);
        int listSize = uzytkownikToList.size();
        UzytkownikTo newRow = new UzytkownikTo(-1l, "", "", true);
        UzytkownikDao daneDAO = new UzytkownikDao();
        Long id = daneDAO.create(newRow);
        if (id != null) {
            newRow.setId(id);
            uzytkownikToList.add(indexObject + 1, newRow);
        }
    }

    public void sort(String dir) {
        java.util.Comparator<UzytkownikTo> comparator = (UzytkownikTo a, UzytkownikTo b)
                -> {
            int compareResult = 0;
            if (dir.equals("asc")) {
                compareResult = a.getNazwisko().compareTo(b.getNazwisko());
            } else {
                compareResult = b.getNazwisko().compareTo(a.getNazwisko());
            }
            return compareResult;
        };
        java.util.Collections.sort(uzytkownikToList, comparator);
    }
    
    
}
