package controllers;

/**
 *
 * @author Admin
 */
public class ApplicationControllerXML {

    String student = "";
    
    public ApplicationControllerXML() {
    }
    
    public String getStudent() {
        return student;
    }

    public void setStudent(String student) {
        this.student = student;
    }
}
