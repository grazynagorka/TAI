package controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Admin
 */
@ManagedBean
@SessionScoped
public class SessionController {

    String sessVariable = "Session Text";
    String nextViewAlias = "index2Alias";
    
    @ManagedProperty(value="#{applicationController}")
        ApplicationController applicationControllerReference;
    
    public SessionController() {
    }
    
    public String getSessVariable() {
        return sessVariable;
    }

    public void setSessVariable(String sessVariable) {
        this.sessVariable = sessVariable;
    }

    public void setApplicationControllerReference(ApplicationController applicationControllerReference) {
        this.applicationControllerReference = applicationControllerReference;
    }
    
    public String getDataFromReference() {
        String appVariableModified = applicationControllerReference.appVariable;
        return appVariableModified + " - modyfikacja";
    }
    
    public String getNextViewAlias() {
        return nextViewAlias;
    }
    
}
