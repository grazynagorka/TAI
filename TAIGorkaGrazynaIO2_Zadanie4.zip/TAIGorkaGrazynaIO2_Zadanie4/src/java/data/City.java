package data;

import java.math.BigDecimal;

/**
 *
 * @author Mariusz
 */
public class City {
     Long id;
     String name;
     String postalCode;
     String president;
     Long residents;
     boolean edited;

    public City(Long id, String name, String postalCode, String president, Long residents, boolean edited) {
        this.id = id;
        this.name = name;
        this.postalCode = postalCode;
        this.president = president;
        this.residents = residents;
        this.edited = edited;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPresident() {
        return president;
    }

    public void setPresident(String president) {
        this.president = president;
    }

    public Long getResidents() {
        return residents;
    }

    public void setResidents(Long residents) {
        this.residents = residents;
    }

    public boolean isEdited() {
        return edited;
    }

    public void setEdited(boolean edited) {
        this.edited = edited;
    }

     
}
