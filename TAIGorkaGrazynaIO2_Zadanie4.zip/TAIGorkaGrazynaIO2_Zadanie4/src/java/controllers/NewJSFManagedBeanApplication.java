package controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ApplicationScoped;

/**
 *
 * @author Mariusz
 */
@ManagedBean
@ApplicationScoped
public class NewJSFManagedBeanApplication {

    public NewJSFManagedBeanApplication() {
    }
    
}
