package controllers;

import data.City;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Mariusz
 */
@ManagedBean(name = "MySessionController")
@SessionScoped
public class MyManagedBeanSession {
    ArrayList<City> citiesList;

    public MyManagedBeanSession() {
        citiesList = new ArrayList();
        citiesList.add(new City(0l,"Sosnowiec","41-200","Checinski",216000l,false));
        citiesList.add(new City(1l,"Katowice","40-360","Poznanski",120000l,false));
        citiesList.add(new City(2l,"Gliwice","42-212","Krzyzowski",300000l,false));
        citiesList.add(new City(3l,"Warszawa","00-999","Mazur",10000000l,false));
    }

    public ArrayList<City> getCitiesList() {
        return citiesList;
    }

    public void setCitiesList(ArrayList<City> citiesList) {
        this.citiesList = citiesList;
    }
  
    public String addRow(City city) {
        int indexObject = citiesList.indexOf(city);
        long nextId = citiesList.size()+1;
        City newCityTO = new City(nextId,"","","",0l,true);
        citiesList.add(indexObject+1, newCityTO);
        return "";
    }
    
    public String delRow(City city) {
        int indexObject = citiesList.indexOf(city);
        citiesList.remove(indexObject);
        return "";
    }
    
    public String modifyRow(City city) {
        int indexObject = citiesList.indexOf(city);
        citiesList.get(indexObject).setEdited(true);
        return "";
    }
    
    public String saveData() {
        for(City city: citiesList)
            city.setEdited(false);
        return "";
    }
    
    public String refreshData() {
        citiesList.clear();
        
        citiesList.add(new City(0l,"Sosnowiec","41-200","Checinski",216000l,false));
        citiesList.add(new City(1l,"Katowice","40-360","Poznanski",120000l,false));
        citiesList.add(new City(2l,"Gliwice","42-212","Krzyzowski",300000l,false));
        citiesList.add(new City(3l,"Warszawa","00-999","Mazur",10000000l,false));
        
        for(City city: citiesList)
            city.setEdited(false);
        return "";
    }
}
