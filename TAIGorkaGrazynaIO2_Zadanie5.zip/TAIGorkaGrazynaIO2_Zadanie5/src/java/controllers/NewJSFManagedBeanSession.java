package controllers;

import dao.DaneDAO;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import to.DaneTO;

@ManagedBean
@RequestScoped
public class NewJSFManagedBeanSession {
    List<DaneTO> daneTO = new ArrayList();

    public NewJSFManagedBeanSession() {
        daneTO.add(new DaneTO(1l,"2020-01","faktura","jeszcze nie wydrukowana",false));
        daneTO.add(new DaneTO(2l,"2020-02","faktura","wydrukowana",false));
        daneTO.add(new DaneTO(3l,"2020-03","faktura","wydrukowana",true));
    }

    public List<DaneTO> getDaneTO() {
        return daneTO;
    }

    public void setDaneTO(List<DaneTO> daneTO) {
        this.daneTO = daneTO;
    }
    
    public String saveData() {
        Iterator<DaneTO> nameIterator = daneTO.iterator();
        while(nameIterator.hasNext())
            nameIterator.next().setEdited(false);
        return "";
    }
    
    public String refreshData() {
        DaneDAO daneDao = new DaneDAO();
        daneTO.clear();
        daneTO=daneDao.findAll();
        return "";
    }
    
    
}
