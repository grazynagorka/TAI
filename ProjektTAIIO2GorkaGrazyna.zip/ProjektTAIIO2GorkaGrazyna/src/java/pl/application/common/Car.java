
package pl.application.common;

public class Car {
    long id;
    String registration;
    String description;
    String model;
    boolean edited;

    public Car(long id, String registration, String description, String model, boolean edited) {
        this.id = id;
        this.registration = registration;
        this.description = description;
        this.model = model;
        this.edited = edited;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getRegistration() {
        return registration;
    }

    public void setRegistration(String registration) {
        this.registration = registration;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public boolean isEdited() {
        return edited;
    }

    public void setEdited(boolean edited) {
        this.edited = edited;
    }


    
}
