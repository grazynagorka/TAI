
package pl.application.common;

public class MenuItem {
   
private String itemName="" ; 
private String itemParam="";

public MenuItem(String itemName, String itemParam) {
this.itemName=itemName; 
this.itemParam=itemParam;
}
public String getItemName() {
return itemName;
}
public String getItemParam() {
    return itemParam;
}

}