package pl.application.controllers;


public class NewJSFManagedBeanView {

    String marka;

    public String getMarka() {
        return marka;
    }

    public void setMarka(String marka) {
        this.marka = marka;
    }
    
    
    
    public NewJSFManagedBeanView() {
    }
    
}
