 
package pl.application.controllers;

import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import pl.application.common.Car;
import pl.application.common.MenuItem;


@ManagedBean(name = "sessionController")
@SessionScoped
public class NewJSFManagedBeanSession {
    ArrayList<MenuItem> menuItemList = new ArrayList();
    ArrayList<Car> cars = new ArrayList();
    
    String wersjaSesji = "Wersja samochodów: 16.12.20"; 

    public String getWersjaSesji() {
        return wersjaSesji;
    }

    public void setWersjaSesji(String wersjaSesji) {
        this.wersjaSesji = wersjaSesji;
    }
    
    
    
    @ManagedProperty(value = "#{applicationController}")
    NewJSFManagedBeanApplication appController;

    public void setAppController(NewJSFManagedBeanApplication appController) {
        this.appController = appController;
    }
    
    public String getDataFromReference() {
        String appVariableModified = appController.version;
        return appVariableModified+" - po wstrzyknieciu";
    }
    
    public String getNextViewAlias() {
        return null;
    }

    public NewJSFManagedBeanSession() {
        menuItemList.add(new MenuItem("Strona glowna","/views/mainView"));
        menuItemList.add(new MenuItem("Samochody","/views/tableView"));
        menuItemList.add(new MenuItem("Faktury","/views/tableAJAXView"));
        menuItemList.add(new MenuItem("Wylogowanie","/logoutWindow"));
        
        
        //long id, String registration, String description, String model, boolean edited
        cars.add(new Car(1, "KOL121216", "Mercedes", "Klasa E", false));
        cars.add(new Car(2, "KOL258596", "Mercedes", "Klasa S", false));
        cars.add(new Car(3, "KOL258596", "Mercedes", "Klasa E", false));
        cars.add(new Car(4, "KOL452452", "BMW", "Seria 3", false));
        cars.add(new Car(5, "KOL965847", "Opel", "Astra", false));
        cars.add(new Car(6, "KOL498324", "Opel", "Corsa", false));
        cars.add(new Car(7, "KOL437289", "Opel", "Mokka", false));
        cars.add(new Car(8, "KOL798454", "Citroen", "C3", false));
    }

    public ArrayList<Car> getCars() {
        return cars;
    }

    public ArrayList<MenuItem> getMenuItemList() {
        return menuItemList;
    }
    
    public String addRow(Car document) {
        int indexObject = cars.indexOf(document);
        long nextId = cars.size()+1;
        Car newPersonTO = new Car(nextId,"","","",true);
        cars.add(indexObject+1, newPersonTO);
        return "";
    }
    
    public String delRow(Car document) {
        int indexObject = cars.indexOf(document);
        cars.remove(indexObject);
        return "";
    }
    
    public String modifyRow(Car document) {
        int indexObject = cars.indexOf(document);
        cars.get(indexObject).setEdited(true);
        return "";
    }
    
    public String saveData() {
        for(Car person: cars)
            person.setEdited(false);
        return "";
    }
    
    public String refreshData() {
        cars.clear();
       
        //long id, String registration, String description, String model, boolean edited
        cars.add(new Car(1, "KOL121216", "Mercedes", "Klasa E", false));
        cars.add(new Car(2, "KOL258596", "Mercedes", "Klasa S", false));
        cars.add(new Car(3, "KOL258596", "Mercedes", "Klasa E", false));
        cars.add(new Car(4, "KOL452452", "BMW", "Seria 3", false));
        cars.add(new Car(5, "KOL965847", "Opel", "Astra", false));
        cars.add(new Car(6, "KOL498324", "Opel", "Corsa", false));
        cars.add(new Car(7, "KOL437289", "Opel", "Mokka", false));
        cars.add(new Car(8, "KOL798454", "Citroen", "C3", false));
        
        for(Car document: cars)
            document.setEdited(false);
        return "";
    }
   
}
