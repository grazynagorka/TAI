
package pl.application.controllers;

import dao.UzytkownikDao;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ApplicationScoped;
import to.UzytkownikTo;


@ManagedBean(name = "applicationController")
@ApplicationScoped
public class NewJSFManagedBeanApplication {
    
    String version="Wersja portalu: 1.0.0"; 

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
   
    java.util.List<UzytkownikTo> uzytkownikToList = new java.util.ArrayList();

    public NewJSFManagedBeanApplication() {
        refreshData();
    }

    public List<UzytkownikTo> getUzytkownikToList() {
        return this.uzytkownikToList;
    }

    public final void refreshData() {
        UzytkownikDao daneDAO = new UzytkownikDao();
        java.util.List<UzytkownikTo> uzytkownikTOListLokal = daneDAO.findAll();
        if (uzytkownikTOListLokal != null) {
            uzytkownikToList.clear();
            uzytkownikToList = uzytkownikTOListLokal;
        }
    }

    public void setUzytkownikToList(List<UzytkownikTo> uzytkownikToList) {
        this.uzytkownikToList = uzytkownikToList;
    }

    public void visibleChange(UzytkownikTo uzytkownikTo) {
        int indexObject = uzytkownikToList.indexOf(uzytkownikTo);
        //uzytkownikTO.setStatus(UzytkownikTo.RowStatus.EDITED);
        UzytkownikDao daneDao = new UzytkownikDao();
        if (daneDao.update(uzytkownikTo) != -1) {
            uzytkownikToList.set(indexObject, uzytkownikTo);
        }

    }

    public void deleteRow(UzytkownikTo uzytkownikTo) {
        int indexObject = uzytkownikToList.indexOf(uzytkownikTo);
        UzytkownikDao daneDao = new UzytkownikDao();
        if (daneDao.delete(uzytkownikTo.getId()) != -1) {
            uzytkownikToList.remove(indexObject);
        }
    }

    public void addRow(UzytkownikTo uzytkownikTo) {
        int indexObject = uzytkownikToList.indexOf(uzytkownikTo);
        int listSize = uzytkownikToList.size();
        UzytkownikTo newRow = new UzytkownikTo(-1l, "", "", true);
        UzytkownikDao daneDAO = new UzytkownikDao();
        Long id = daneDAO.create(newRow);
        if (id != null) {
            newRow.setId(id);
            uzytkownikToList.add(indexObject + 1, newRow);
        }
    }  
}
